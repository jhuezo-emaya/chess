# Chess Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/unscsprt/pen/KKogxK](https://codepen.io/unscsprt/pen/KKogxK).

A simple chess clock styled with Flat UI.